<?php

//Dbconfig.php

// $connect = new PDO('mysql:host=localhost;dbname=data_img', 'root', '');
$connect = new PDO('mysql:host=127.0.0.1:3307;dbname=sling-website', 'root', '');
// $con = mysqli_connect("localhost","slinggro_siva","sivA@12$","slinggro_mmbiriyani");

// $connect = new PDO('mysql:host=localhost;dbname=slinggro_slingwebsite', 'slinggro_slingwebsite', '_MzK)ZfDL%t6');

?>